//products

// Example product data (replace this with your actual product data)
const products = [
    { 
        name: "Product 1",
        image: "phone.png",
        price: "$19.99",
        details: "Product details here",
        link: "product_details.html"
    },
    { 
        name: "Product 2",
        image: "toy.jpg",
        price: "$24.99",
        details: "Product details here",
        link: "product_details.html"
    },

    { 
        name: "Product 1",
        image: "mk.jpeg",
        price: "$19.99",
        details: "Product details here",
        link: "product_details.html"
    },
    { 
        name: "Product 2",
        image: "clo.jpg",
        price: "$24.99",
        details: "Product details here",
        link: "product_details.html"
    },

    { 
        name: "Product 1",
        image: "bo.jpg",
        price: "$19.99",
        details: "Product details here",
        link: "product_details.html"
    },
    { 
        name: "Product 2",
        image: "so.jpg",
        price: "$24.99",
        details: "Product details here",
        link: "product_details.html"
    },

    { 
        name: "Product 1",
        image: "al.jpeg",
        price: "$19.99",
        details: "Product details here",
        link: "product_details.html"
    },
    { 
        name: "Product 2",
        image: "la.jpg",
        price: "$24.99",
        details: "Product details here",
        link: "product_details.html"
    },
    // Add more product objects as needed
];

// Function to generate the HTML for each product
function generateProductHTML(product) {
    return `
        <div class="product">
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price}</p>
            <a href="${product.link}">View Details</a>
        </div>
    `;
}

// Function to populate the products section with the generated HTML
function renderProducts() {
    const productsSection = document.getElementById('productsSection');
    const productList = productsSection.querySelector('.product-list');

    // Generate the HTML for each product and append it to the product list
    products.forEach(product => {
        const productHTML = generateProductHTML(product);
        productList.insertAdjacentHTML('beforeend', productHTML);
    });
}

// Call the renderProducts function to populate the products section
renderProducts();


//testimonials






//popular products

// Example popular product data (replace this with your actual popular product data)
const popularProducts = [
    { 
        name: "Product A",
        image: "ipo.png",
        price: "$29.99",
        details: "Popular product details here",
        link: "product_details.html"
    },
    { 
        name: "Product B",
        image: "ri.jpeg",
        price: "$39.99",
        details: "Popular product details here",
        link: "product_details.html"
    },
    { 
        name: "Product A",
        image: "ai.jpg",
        price: "$29.99",
        details: "Popular product details here",
        link: "product_details.html"
    },
    { 
        name: "Product B",
        image: "sun.jpeg",
        price: "$39.99",
        details: "Popular product details here",
        link: "product_details.html"
    },
    { 
        name: "Product A",
        image: "wa.png",
        price: "$29.99",
        details: "Popular product details here",
        link: "product_details.html"
    },
    // Add more popular product objects as needed
];

// Function to generate the HTML for each popular product
function generatePopularProductHTML(product) {
    return `
        <div class="product">
            <img src="${product.image}" alt="${product.name}">
            <h3>${product.name}</h3>
            <p>${product.price}</p>
            <a href="${product.link}">View Details</a>
        </div>
    `;
}

// Function to populate the popular products section with the generated HTML
function renderPopularProducts() {
    const popularProductsSection = document.getElementById('popularProductsSection');
    const productContainer = popularProductsSection.querySelector('.product-list');

    // Generate the HTML for each popular product and append it to the product container
    popularProducts.forEach(product => {
        const productHTML = generatePopularProductHTML(product);
        productContainer.innerHTML += productHTML;
    });
}

// Call the function to render the popular products section
renderPopularProducts();
